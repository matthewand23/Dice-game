// Matthew Anderson
// CSC 160 Section 178
// 04/27/2021
// dice game between two players first to 30!

package Dicegame;
import java.util.Scanner;
public class Dicegame {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		// set the players
		String firstPlayer, secondPlayer;
		
		// first user input
		System.out.println("Hello! What is the name of player one?");
		firstPlayer = sc.nextLine();
				
		// second user input
		System.out.println("Hello! what is the name of player two?");
		secondPlayer = sc.nextLine();
				
		// rules of the game
		System.out.println("The goal of the game is to score exactly 30. You will roll two dice and chose the value of either both or one dice. if your score goes over 30, your scor resets to zero. the first player to accumulate exactly 30 wins!");
		
		// int for 6 sided die (1)
		int D1; 
		// int for 6 sided die (2)
		int D2;
		// total of both die
		int total; 
		
		
		// first player start at 0
		int firstPlayerSum = 0;
		// second player start at 0
		int secondPlayerSum = 0;
		
		
		// infinite loop for player one to play game
		while(true) {
			System.out.println("Player " +firstPlayer+ " your turn!");
			System.out.println("Your score: " +firstPlayerSum);
			System.out.println("Your role: ");
			
			// die value
			// returns different values when called twice(6 sided die)
			D1 = (int)(Math.random()*6) +1;
			D2 = (int)(Math.random()*6) +1;
			
			// if player selects both rolls
			total = D1+D2;
			
			// print statements of random rolls
			System.out.println("Die 1: " +D1);
			System.out.println("Die 2: " +D2);
			System.out.println("Total: " +total);
			// print statement for selecting which die or both for score
			System.out.println("Would you like to keep Die 1 (1), or keep die 2 (2), or keep the total? (3). Respond with 1 or 2 or 3");
			
			// in order for player to choose
			int selection;
			selection = sc.nextInt();
			
			// if statement for player to choose first die
			if (selection == 1) {
				firstPlayerSum = firstPlayerSum + D1;
				System.out.println("Your Score is: " +firstPlayerSum);
			}	
			// else if for player to choose second die
			else if (selection == 2) {
					firstPlayerSum = firstPlayerSum + D2;
					System.out.println("Your Score is: " +firstPlayerSum);
			}
			//continue else if statement for player choose total of both die
			else if (selection == 3) {
				firstPlayerSum = firstPlayerSum + total;
				System.out.println("Your Score is: " +firstPlayerSum );
				}
			// if statement if first player score is over 30 score resets to 0
			if (firstPlayerSum>30) {
				firstPlayerSum = 0;
			}
			// if statement is equal to 30 player wins
			if (firstPlayerSum == 30) { 
				System.out.println("Your score is 30! You win!");
				// end loop
				break;
			}
			
			// second player
			System.out.println("Player "+secondPlayer+" it is your turn");
			System.out.println("Your score: "+secondPlayerSum);
			System.out.println("Your role: ");
			
			//die value
			// returns different values when called twice(6 sided die)
			D1 = (int)(Math.random()*6) +1;
			D2 = (int)(Math.random()*6) +1;
			
			// total if player chooses both die
			total = D1+D2;
			
			// print statement of random rolls
			System.out.println("Die 1: " +D1);
			System.out.println("Die 2: " +D2);
			System.out.println("Total: " +total);
			// print statement for player to choose which die to choose or both
			System.out.println("Would you like to keep Die 1 (1), or keep die 2 (2), or keep the total? (3). Respond with 1 or 2 or 3");
			
			// for player two to choose
			int selectionTwo;
			selectionTwo = sc.nextInt();
			
			// allows player two to choose first die
			if (selectionTwo == 1) {
				secondPlayerSum = secondPlayerSum + D1;
				System.out.println("Your total: " +secondPlayerSum);
			}
			// else if allows player two to choose second die
			else if (selectionTwo == 2) {
				secondPlayerSum = secondPlayerSum + D2;
				System.out.println("Your total: " +secondPlayerSum);
			}
			// else if allows player two to choose both die 
			else if (selectionTwo == 3) {
				secondPlayerSum = secondPlayerSum + total;
				System.out.println("Your total: " +secondPlayerSum);
			}
			// if player is over 30 score resets to 0
			if (secondPlayerSum > 30) {
				secondPlayerSum = 0;
			}
			// if players two score eaqual's 30 player wins
			if (secondPlayerSum == 30) {
				System.out.println("Your Score is 30! You win!");
				// end loop
				break;
			}
		}
	}
}